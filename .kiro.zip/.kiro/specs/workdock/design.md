# Design Document: Workdock

## Overview

Workdock is a cloud-native, microservices-based Business Intelligence platform that provides real-time financial insights to business owners. The system follows a layered architecture with clear separation between presentation (React), API management (API Gateway), business logic (Java microservices), AI/ML capabilities (Python services), and data persistence (SQL/NoSQL).

The architecture is designed for:
- **Real-time performance**: Sub-second response times for dashboard updates
- **Scalability**: Horizontal scaling of all services to handle growth
- **Reliability**: 99.9% uptime with automatic failover
- **Security**: End-to-end encryption and role-based access control
- **Extensibility**: Plugin architecture for adding new data sources

### Key Design Principles

1. **Microservices Architecture**: Each business capability is an independent service
2. **Event-Driven Communication**: Services communicate via message queues for loose coupling
3. **CQRS Pattern**: Separate read and write models for optimal performance
4. **API-First Design**: All functionality exposed through well-defined REST APIs
5. **Cloud-Native**: Containerized services deployed on Kubernetes
6. **Security by Design**: Zero-trust security model with encryption everywhere

## Architecture

### High-Level Architecture

```mermaid
graph TB
    subgraph "Client Layer"
        WEB[React Dashboard]
        MOBILE[Mobile App]
    end
    
    subgraph "API Layer"
        APIGW[API Gateway]
        AUTH[Auth Service]
    end
    
    subgraph "Business Logic Layer - Java Microservices"
        AGG[Data Aggregator Service]
        METRICS[Metrics Engine Service]
        ALERT[Alert Manager Service]
        USER[User Management Service]
        CONN[Connection Manager Service]
    end
    
    subgraph "AI/ML Layer - Python Services"
        FORECAST[ML Forecaster Service]
        ANOMALY[Anomaly Detector Service]
        INSIGHT[Insight Generator Service]
    end
    
    subgraph "Data Layer"
        POSTGRES[(PostgreSQL)]
        MONGO[(MongoDB)]
        REDIS[(Redis Cache)]
        TIMESERIES[(TimescaleDB)]
    end
    
    subgraph "Message Queue"
        KAFKA[Apache Kafka]
    end
    
    subgraph "External Systems"
        BANK[Banking APIs]
        PAYMENT[Payment Gateways]
        ACCT[Accounting Software]
        SALES[Sales Platforms]
    end
    
    WEB --> APIGW
    MOBILE --> APIGW
    APIGW --> AUTH
    APIGW --> AGG
    APIGW --> METRICS
    APIGW --> ALERT
    APIGW --> USER
    
    AGG --> BANK
    AGG --> PAYMENT
    AGG --> ACCT
    AGG --> SALES
    
    AGG --> KAFKA
    KAFKA --> METRICS
    KAFKA --> FORECAST
    KAFKA --> ANOMALY
    
    METRICS --> KAFKA
    KAFKA --> INSIGHT
    KAFKA --> ALERT
    
    ANOMALY --> KAFKA
    
    AGG --> POSTGRES
    METRICS --> TIMESERIES
    USER --> POSTGRES
    CONN --> POSTGRES
    
    FORECAST --> MONGO
    ANOMALY --> MONGO
    INSIGHT --> MONGO
    
    APIGW --> REDIS
    METRICS --> REDIS
```

### Service Responsibilities

**API Gateway**:
- Request routing and load balancing
- Rate limiting and throttling
- Request/response transformation
- API versioning
- Caching frequently accessed data

**Auth Service (Java)**:
- User authentication (JWT-based)
- Multi-factor authentication
- Role-based access control (RBAC)
- Session management
- Token validation and refresh

**Data Aggregator Service (Java)**:
- Connect to external data sources via APIs
- Poll sources every 5 minutes for new data
- Normalize data into standard format
- Handle connection failures with retry logic
- Publish raw transaction events to Kafka

**Metrics Engine Service (Java)**:
- Subscribe to transaction events from Kafka
- Calculate business metrics in real-time
- Maintain running totals and aggregations
- Store time-series data in TimescaleDB
- Publish metric update events to Kafka
- Serve metric queries via REST API

**ML Forecaster Service (Python)**:
- Train forecasting models on historical data
- Generate 30/60/90 day revenue and expense forecasts
- Retrain models weekly
- Calculate confidence intervals
- Store forecasts in MongoDB
- Expose predictions via REST API

**Anomaly Detector Service (Python)**:
- Subscribe to transaction events from Kafka
- Apply statistical anomaly detection algorithms
- Detect unusual spending patterns
- Identify financial risks
- Publish anomaly events to Kafka
- Store anomaly history in MongoDB

**Insight Generator Service (Python)**:
- Subscribe to metric update events from Kafka
- Analyze business performance trends
- Generate actionable recommendations using rule engine
- Prioritize insights by financial impact
- Store insights in MongoDB
- Expose insights via REST API

**Alert Manager Service (Java)**:
- Subscribe to anomaly and critical events from Kafka
- Route alerts to appropriate channels (email, SMS, push)
- Manage alert preferences per user
- Implement deduplication logic
- Track alert delivery status
- Store alert history in PostgreSQL

**User Management Service (Java)**:
- Manage user accounts and profiles
- Handle business-user relationships
- Manage team invitations
- Store user data in PostgreSQL

**Connection Manager Service (Java)**:
- Manage external source connections
- Store OAuth tokens securely
- Monitor connection health
- Handle credential refresh
- Store connection metadata in PostgreSQL

## Components and Interfaces

### Data Aggregator Service

**Technology**: Java 17, Spring Boot, Spring Integration

**Responsibilities**:
- Integrate with external financial data sources
- Normalize heterogeneous data formats
- Handle authentication and token management
- Implement retry logic with exponential backoff

**Key Classes**:

```java
// Connector interface for external sources
interface ExternalSourceConnector {
    ConnectionStatus connect(ConnectionConfig config);
    List<Transaction> fetchTransactions(LocalDateTime since);
    void disconnect();
    boolean isHealthy();
}

// Implementations for different source types
class PlaidBankingConnector implements ExternalSourceConnector
class StripePaymentConnector implements ExternalSourceConnector
class QuickBooksConnector implements ExternalSourceConnector
class ShopifyConnector implements ExternalSourceConnector

// Main aggregation orchestrator
class DataAggregationOrchestrator {
    void schedulePolling(String businessId, String sourceId);
    void handleNewTransactions(List<Transaction> transactions);
    void publishToKafka(TransactionEvent event);
}

// Data normalization
class TransactionNormalizer {
    StandardTransaction normalize(RawTransaction raw, SourceType type);
}
```

**REST API Endpoints**:
- `POST /api/v1/sources/connect` - Connect new external source
- `GET /api/v1/sources/{sourceId}/status` - Get connection status
- `DELETE /api/v1/sources/{sourceId}` - Disconnect source
- `POST /api/v1/sources/{sourceId}/sync` - Trigger manual sync

**Kafka Topics**:
- Produces: `transactions.raw` - Raw transaction events
- Produces: `connections.status` - Connection status updates

### Metrics Engine Service

**Technology**: Java 17, Spring Boot, Spring Data JPA

**Responsibilities**:
- Calculate business metrics in real-time
- Maintain time-series data
- Serve metric queries efficiently
- Handle metric recalculations

**Key Classes**:

```java
// Metric calculation engine
class MetricsCalculator {
    MetricValue calculateRevenue(String businessId, TimeRange range);
    MetricValue calculateExpenses(String businessId, TimeRange range);
    MetricValue calculateProfitMargin(String businessId, TimeRange range);
    MetricValue calculateCashFlow(String businessId, TimeRange range);
    MetricValue calculateBurnRate(String businessId);
}

// Time-series data management
class TimeSeriesRepository {
    void storeMetric(String businessId, MetricType type, 
                    LocalDateTime timestamp, BigDecimal value);
    List<MetricDataPoint> queryMetrics(String businessId, 
                                       MetricType type, TimeRange range);
}

// Event handlers
class TransactionEventHandler {
    void onTransactionReceived(TransactionEvent event);
    void updateAffectedMetrics(Transaction transaction);
}
```

**REST API Endpoints**:
- `GET /api/v1/metrics/{businessId}/revenue` - Get revenue metrics
- `GET /api/v1/metrics/{businessId}/expenses` - Get expense metrics
- `GET /api/v1/metrics/{businessId}/profit-margin` - Get profit margin
- `GET /api/v1/metrics/{businessId}/cash-flow` - Get cash flow
- `GET /api/v1/metrics/{businessId}/summary` - Get all key metrics

**Kafka Topics**:
- Consumes: `transactions.raw` - Transaction events
- Produces: `metrics.updated` - Metric update events

### ML Forecaster Service

**Technology**: Python 3.11, FastAPI, scikit-learn, Prophet, TensorFlow

**Responsibilities**:
- Train time-series forecasting models
- Generate revenue and expense predictions
- Calculate confidence intervals
- Retrain models periodically

**Key Modules**:

```python
# Model training and prediction
class ForecastingModel:
    def train(self, historical_data: pd.DataFrame) -> None:
        """Train model on historical time-series data"""
        
    def predict(self, horizon_days: int) -> ForecastResult:
        """Generate forecast with confidence intervals"""
        
    def evaluate(self, test_data: pd.DataFrame) -> ModelMetrics:
        """Evaluate model accuracy"""

# Model selection and management
class ModelManager:
    def select_best_model(self, data: pd.DataFrame) -> str:
        """Choose between Prophet, ARIMA, LSTM based on data characteristics"""
        
    def should_retrain(self, model_id: str) -> bool:
        """Determine if model needs retraining based on accuracy drift"""

# Forecasting service
class ForecastService:
    def generate_revenue_forecast(self, business_id: str, 
                                  horizon: int) -> Forecast:
        """Generate revenue forecast for specified horizon"""
        
    def generate_expense_forecast(self, business_id: str, 
                                  horizon: int) -> Forecast:
        """Generate expense forecast for specified horizon"""
```

**REST API Endpoints**:
- `GET /api/v1/forecasts/{businessId}/revenue?horizon=30` - Get revenue forecast
- `GET /api/v1/forecasts/{businessId}/expenses?horizon=30` - Get expense forecast
- `POST /api/v1/forecasts/{businessId}/retrain` - Trigger model retraining
- `GET /api/v1/forecasts/{businessId}/accuracy` - Get model accuracy metrics

### Anomaly Detector Service

**Technology**: Python 3.11, FastAPI, scikit-learn, NumPy

**Responsibilities**:
- Detect statistical anomalies in transactions
- Identify financial risks
- Learn normal patterns per business
- Generate risk scores

**Key Modules**:

```python
# Anomaly detection algorithms
class AnomalyDetector:
    def detect_statistical_anomaly(self, transaction: Transaction, 
                                   historical: pd.DataFrame) -> AnomalyScore:
        """Use z-score and IQR methods to detect outliers"""
        
    def detect_pattern_anomaly(self, recent_data: pd.DataFrame) -> List[Anomaly]:
        """Detect unusual patterns like sudden spikes or drops"""

# Risk assessment
class RiskAnalyzer:
    def assess_cash_flow_risk(self, business_id: str) -> RiskLevel:
        """Predict if cash flow will reach zero within 30 days"""
        
    def assess_expense_risk(self, business_id: str) -> RiskLevel:
        """Detect unusual expense increases"""
        
    def assess_revenue_risk(self, business_id: str) -> RiskLevel:
        """Detect concerning revenue decreases"""

# Learning system
class PatternLearner:
    def learn_normal_patterns(self, business_id: str, 
                             data: pd.DataFrame) -> BusinessProfile:
        """Build statistical profile of normal business behavior"""
```

**REST API Endpoints**:
- `GET /api/v1/anomalies/{businessId}` - Get detected anomalies
- `GET /api/v1/risks/{businessId}` - Get current risk assessment
- `POST /api/v1/anomalies/{anomalyId}/feedback` - Provide feedback on anomaly

**Kafka Topics**:
- Consumes: `transactions.raw` - Transaction events
- Produces: `anomalies.detected` - Anomaly events
- Produces: `risks.identified` - Risk events

### Insight Generator Service

**Technology**: Python 3.11, FastAPI, rule engine

**Responsibilities**:
- Analyze business performance
- Generate actionable recommendations
- Prioritize insights by impact
- Track recommendation outcomes

**Key Modules**:

```python
# Insight generation rules
class InsightRules:
    def analyze_profit_margin(self, metrics: BusinessMetrics) -> List[Insight]:
        """Generate insights about profit margin trends"""
        
    def analyze_cash_flow(self, metrics: BusinessMetrics) -> List[Insight]:
        """Generate insights about cash flow health"""
        
    def analyze_growth(self, metrics: BusinessMetrics) -> List[Insight]:
        """Generate insights about revenue growth"""

# Recommendation engine
class RecommendationEngine:
    def generate_cost_reduction_recommendations(
        self, business_id: str) -> List[Recommendation]:
        """Suggest specific areas to reduce costs"""
        
    def generate_investment_recommendations(
        self, business_id: str) -> List[Recommendation]:
        """Suggest investment opportunities"""

# Impact calculator
class ImpactCalculator:
    def estimate_financial_impact(self, recommendation: Recommendation) -> Money:
        """Estimate potential financial benefit"""
        
    def prioritize_insights(self, insights: List[Insight]) -> List[Insight]:
        """Sort insights by potential impact"""
```

**REST API Endpoints**:
- `GET /api/v1/insights/{businessId}` - Get current insights
- `GET /api/v1/recommendations/{businessId}` - Get recommendations
- `POST /api/v1/recommendations/{recId}/action` - Record action taken
- `GET /api/v1/insights/{businessId}/history` - Get historical insights

**Kafka Topics**:
- Consumes: `metrics.updated` - Metric update events
- Produces: `insights.generated` - New insight events

### Alert Manager Service

**Technology**: Java 17, Spring Boot, Twilio (SMS), SendGrid (Email)

**Responsibilities**:
- Route alerts to appropriate channels
- Manage user alert preferences
- Implement deduplication
- Track delivery status

**Key Classes**:

```java
// Alert routing
class AlertRouter {
    void routeAlert(Alert alert, User user);
    List<NotificationChannel> determineChannels(Alert alert, 
                                                AlertPreferences prefs);
}

// Channel implementations
interface NotificationChannel {
    DeliveryStatus send(Alert alert, User user);
}

class EmailChannel implements NotificationChannel
class SMSChannel implements NotificationChannel
class PushNotificationChannel implements NotificationChannel

// Deduplication
class AlertDeduplicator {
    boolean isDuplicate(Alert alert, Duration window);
    void recordAlert(Alert alert);
}

// Preference management
class AlertPreferenceManager {
    AlertPreferences getPreferences(String userId);
    void updatePreferences(String userId, AlertPreferences prefs);
}
```

**REST API Endpoints**:
- `GET /api/v1/alerts/{businessId}` - Get alert history
- `GET /api/v1/alerts/preferences` - Get user alert preferences
- `PUT /api/v1/alerts/preferences` - Update alert preferences
- `POST /api/v1/alerts/{alertId}/acknowledge` - Acknowledge alert

**Kafka Topics**:
- Consumes: `anomalies.detected` - Anomaly events
- Consumes: `risks.identified` - Risk events
- Consumes: `connections.status` - Connection status updates

### Auth Service

**Technology**: Java 17, Spring Boot, Spring Security, JWT

**Responsibilities**:
- Authenticate users
- Issue and validate JWT tokens
- Enforce role-based access control
- Manage MFA

**Key Classes**:

```java
// Authentication
class AuthenticationService {
    AuthToken authenticate(String email, String password);
    AuthToken refreshToken(String refreshToken);
    void logout(String token);
}

// MFA management
class MFAService {
    String generateMFASecret(String userId);
    boolean verifyMFACode(String userId, String code);
    void enableMFA(String userId);
}

// Authorization
class AuthorizationService {
    boolean hasPermission(String userId, String resource, Permission perm);
    Role getUserRole(String userId, String businessId);
}

// Token management
class JWTTokenProvider {
    String generateAccessToken(User user, List<Role> roles);
    String generateRefreshToken(User user);
    Claims validateToken(String token);
}
```

**REST API Endpoints**:
- `POST /api/v1/auth/login` - User login
- `POST /api/v1/auth/logout` - User logout
- `POST /api/v1/auth/refresh` - Refresh access token
- `POST /api/v1/auth/mfa/enable` - Enable MFA
- `POST /api/v1/auth/mfa/verify` - Verify MFA code

## Data Models

### Core Domain Models

**Transaction**:
```java
class Transaction {
    UUID id;
    String businessId;
    String sourceId;
    TransactionType type;  // REVENUE, EXPENSE
    BigDecimal amount;
    String currency;
    LocalDateTime timestamp;
    String category;
    String description;
    String externalId;
    Map<String, String> metadata;
}
```

**BusinessMetric**:
```java
class BusinessMetric {
    UUID id;
    String businessId;
    MetricType type;  // REVENUE, EXPENSES, PROFIT_MARGIN, CASH_FLOW, BURN_RATE
    BigDecimal value;
    String unit;
    LocalDateTime timestamp;
    TimeRange period;
    BigDecimal changePercent;
    TrendDirection trend;  // UP, DOWN, STABLE
}
```

**Forecast**:
```python
@dataclass
class Forecast:
    id: str
    business_id: str
    metric_type: str  # REVENUE, EXPENSES
    horizon_days: int
    predictions: List[ForecastPoint]
    confidence_level: float
    model_type: str
    generated_at: datetime
    
@dataclass
class ForecastPoint:
    date: datetime
    predicted_value: Decimal
    lower_bound: Decimal
    upper_bound: Decimal
```

**Anomaly**:
```python
@dataclass
class Anomaly:
    id: str
    business_id: str
    transaction_id: str
    anomaly_type: str  # STATISTICAL, PATTERN, RISK
    severity: str  # LOW, MEDIUM, HIGH, CRITICAL
    score: float
    description: str
    detected_at: datetime
    acknowledged: bool
```

**Insight**:
```python
@dataclass
class Insight:
    id: str
    business_id: str
    insight_type: str  # COST_REDUCTION, INVESTMENT, OPTIMIZATION
    title: str
    description: str
    recommendations: List[Recommendation]
    priority: int
    estimated_impact: Decimal
    generated_at: datetime
    
@dataclass
class Recommendation:
    action: str
    expected_outcome: str
    effort_level: str  # LOW, MEDIUM, HIGH
```

**User**:
```java
class User {
    UUID id;
    String email;
    String passwordHash;
    String firstName;
    String lastName;
    boolean mfaEnabled;
    String mfaSecret;
    LocalDateTime createdAt;
    LocalDateTime lastLoginAt;
}
```

**Business**:
```java
class Business {
    UUID id;
    String name;
    String industry;
    LocalDateTime createdAt;
    List<ExternalSource> connectedSources;
}
```

**BusinessUser**:
```java
class BusinessUser {
    UUID id;
    UUID businessId;
    UUID userId;
    Role role;  // OWNER, MANAGER, VIEWER
    LocalDateTime joinedAt;
    boolean active;
}
```

**ExternalSource**:
```java
class ExternalSource {
    UUID id;
    String businessId;
    SourceType type;  // BANKING, PAYMENT, ACCOUNTING, SALES
    String provider;  // PLAID, STRIPE, QUICKBOOKS, SHOPIFY
    ConnectionStatus status;
    LocalDateTime lastSyncAt;
    Map<String, String> credentials;  // Encrypted
}
```

### Database Schema Design

**PostgreSQL** (Relational data):
- `users` - User accounts
- `businesses` - Business entities
- `business_users` - Many-to-many relationship with roles
- `external_sources` - Connected data sources
- `alert_preferences` - User alert settings
- `audit_logs` - System audit trail

**TimescaleDB** (Time-series data):
- `transactions` - All financial transactions (hypertable)
- `metrics` - Calculated business metrics (hypertable)
- Automatic data retention policies
- Continuous aggregates for common queries

**MongoDB** (Document storage):
- `forecasts` - ML-generated forecasts
- `anomalies` - Detected anomalies
- `insights` - Generated insights and recommendations
- `model_metadata` - ML model versions and performance

**Redis** (Caching):
- Session tokens
- Frequently accessed metrics
- API response cache
- Rate limiting counters

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*
